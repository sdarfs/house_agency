create procedure "AddRequest"(IN "InNumber" character varying, IN "InDetails" text, IN "InHouseId" integer, IN "InRequestStateId" integer, IN "InClientId" integer, IN "InRequestTypeId" integer, IN "InDepartmentId" integer)
    language plpgsql
as
$$begin
    insert into "Request"(
        "number",
        "createStamp",
        "details",
        "HouseId",
        "RequestStateId",
        "ClientId",
        "RequestTypeId",
        "DepartmentId"
    )
    values(
              "InNumber",
              LOCALTIMESTAMP,
              "InDetails",
              "InHouseId",
              "InRequestStateId",
              "InClientId",
              "InRequestTypeId",
              "InDepartmentId"
          );
end;$$;

alter procedure "AddRequest"(varchar, text, integer, integer, integer, integer, integer) owner to postgres;

