create function "docTypeUpdate"() returns trigger
    language plpgsql
as
$$begin
    update "DocumentType"
    set "updateStamp" = LOCALTIMESTAMP
    where new."id" = "id";
    return new;
end;$$;

alter function "docTypeUpdate"() owner to postgres;

