create procedure upsert_passport(IN p_clientid integer, IN p_series text, IN p_number text, IN p_issuedby text, IN p_issueddate date, IN p_birthday date)
    language plpgsql
as
$$
DECLARE
    v_is_archive BOOLEAN;
BEGIN
    -- Проверяем значение is_Archive для записи с указанным ClientId
    SELECT is_Archive INTO v_is_archive
    FROM "Passport"
    WHERE "ClientId" = p_ClientId;

    IF v_is_archive IS NULL THEN
        -- Если is_Archive пустое, выполняем INSERT
        INSERT INTO "Passport" ("ClientId", "series", "number", "issuedBy", "issuedDate", "birthday")
        VALUES (p_ClientId, p_series, p_number, p_issuedBy, p_issuedDate, p_birthday);
    ELSIF v_is_archive = TRUE THEN
        -- Если is_Archive TRUE, выполняем UPDATE
        UPDATE "Passport"
        SET 
            "series" = p_series,
            "number" = p_number,
            "issuedBy" = p_issuedBy,
            "issuedDate" = p_issuedDate,
            "birthday" = p_birthday
        WHERE "ClientId" = p_ClientId;
    END IF;
END $$;

alter procedure upsert_passport(integer, text, text, text, date, date) owner to postgres;

