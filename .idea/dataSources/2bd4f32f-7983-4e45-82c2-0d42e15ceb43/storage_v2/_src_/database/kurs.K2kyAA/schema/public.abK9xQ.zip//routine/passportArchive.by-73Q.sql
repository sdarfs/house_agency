create function "passportArchive"() returns trigger
    language plpgsql
as
$$
begin
    update "Passport"
    set "isArchive" = true
    where
        ("WorkerId" is null and new."ClientId" = "ClientId")
       or
        ("ClientId" is null and new."WorkerId" = "WorkerId");

    return new;
end;
$$;

alter function "passportArchive"() owner to postgres;

