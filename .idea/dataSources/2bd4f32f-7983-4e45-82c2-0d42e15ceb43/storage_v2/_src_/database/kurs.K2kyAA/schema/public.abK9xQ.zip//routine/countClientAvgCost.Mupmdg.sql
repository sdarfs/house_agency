create function "countClientAvgCost"("InClientId" integer) returns bigint
    language plpgsql
as
$$declare
    cCost bigint;
begin
    select avg("House"."cost") into cCost
    from "House"
             join "Request" on "House"."id" = "Request"."HouseId"
             join "Client" on "Client"."id" = "Request"."ClientId"
    where "Client"."id" = "InClientId";

    return cCost;
end;$$;

alter function "countClientAvgCost"(integer) owner to postgres;

