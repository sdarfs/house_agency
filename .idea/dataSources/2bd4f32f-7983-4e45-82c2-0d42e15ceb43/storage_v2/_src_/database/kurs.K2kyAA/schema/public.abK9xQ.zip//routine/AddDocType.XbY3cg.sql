create procedure "AddDocType"(IN "InFileName" character varying)
    language plpgsql
as
$$begin
    insert into "DocumentType" ("updateStamp", "fileName")
    values (LOCALTIMESTAMP, "InFileName");
end;$$;

alter procedure "AddDocType"(varchar) owner to postgres;

