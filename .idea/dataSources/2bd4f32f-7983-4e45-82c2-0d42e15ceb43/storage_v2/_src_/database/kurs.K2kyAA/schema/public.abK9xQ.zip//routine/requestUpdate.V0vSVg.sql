create function "requestUpdate"() returns trigger
    language plpgsql
as
$$begin
    update "Request"
    set "statusUpdateStamp" = LOCALTIMESTAMP
    where new."id" = "id";
    return new;
end;$$;

alter function "requestUpdate"() owner to postgres;

